const answers = [
  {
    key: 0,
    questionId: 0,
    trueAnswer: 1,
    data: [
      {
        id: 0,
        answer: 'Daulet'
      },
      {
        id: 1,
        answer: "Amandos"
      },
      {
        id: 2,
        answer: "Jandos"
      }
    ],
  },
  {
    key: 1,
    questionId: 1,
    trueAnswer: 0,
    data: [
      {
        id: 0,
        answer: 'Almaty'
      },
      {
        id: 1,
        answer: "Astana"
      },
      {
        id: 2,
        answer: "Aktau"
      }
    ],
  },
  {
    key: 2,
    questionId: 2,
    trueAnswer: 0,
    data: [
      {
        id: 0,
        answer: 'Kulash'
      },
    ],
  },
];

export default {
  getAnswers: (config) => {
    const {questionId} = JSON.parse(config.body);
    const data = answers.filter((item) => item.questionId === questionId);
    return {
      status: 0,
      data: data,
    };
  },
  deleteAnswer: (config) => {
    const {key} = JSON.parse(config.body);
    const item = answers.filter((item) => item.key === key);
    const index = answers.indexOf(item[0]);
    answers.splice(index, 1);
    return {
      status: 0,
    };
  },
  addAnswer: (config) => {
    const {questionId,trueAnswer,data} = JSON.parse(config.body);
    answers.push({key: answers.length,questionId: questionId,trueAnswer: trueAnswer, data: data});
    return {
      status: 0,
    };
  }
};

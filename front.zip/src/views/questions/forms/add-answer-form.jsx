import React, { useImperativeHandle } from "react";
import { Form, Input, Radio, Modal,Icon} from "antd";
const AddAnswerForm = Form.create({
  name: "addAnswerForm"
})(
React.forwardRef((props, ref) => {
  const { visible,onCancel, onOk, form, questionActive,answers,confirmLoading } = props;
  const { getFieldDecorator } = form;

  useImperativeHandle(ref, () => ({
    form
  }));
  const formItemLayout = {
    labelCol: {
      sm: { span: 8 },
    },
    wrapperCol: {
      sm: { span: 10 },
    },
  };
  console.log(questionActive,answers);
  
  return (
    <Modal
      title={questionActive.question}
      visible={visible}
      onCancel={onCancel}
      onOk={onOk}
      confirmLoading={confirmLoading}
      okText={"Қосу"}
      cancelText={"Жабу"}
    >
        
      {
        answers.length > 0 ?
        questionActive.type === 0 ? 
            <Radio.Group value={answers[0].trueAnswer}>
                {
                  answers[0].data.map(function(item){
                    return(
                      <Radio value={item.id}>{item.answer}</Radio>
                    )
                  })      
                }
            </Radio.Group>
          :
            <Input /> 
        : false}
        
    </Modal>
  );
}))

export default AddAnswerForm;

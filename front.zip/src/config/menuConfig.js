const menuList = [
  {
    title: "Сыныптар",
    path: "/classes",
    icon: "home",
    roles:["admin","editor","guest"]
  },
  {
    title: "БЖБ",
    path: "/exams",
    icon: "file",
    roles:["admin","editor","guest"]
  },
];
export default menuList;
